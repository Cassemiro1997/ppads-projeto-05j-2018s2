<?php 
	header ('Content-type: text/html; charset="utf-8"');
	include("config.php");
	
	$nome_doador = $_POST['nome_doador'];
	$descricao = $_POST['descricao'];
	$quantidade = $_POST['quantidade'];
	$qualidade = $_POST['qualidade'];
	$retirada = $_POST['retirada'];
	$entrega = $_POST['entrega'];
	
	if(mysqli_query($conexao, "INSERT INTO doador (nome, descricao, qualidade, quantidade, retirada, entrega)VALUES('$nome_doador', '$descricao', '$quantidade', '$qualidade', '$retirada', '$entrega')"))
	{
		echo "INCLUS�O FEITA COM SUCESSO! <a href='../inserirDoador.php'>VOLTAR</a>";
	}
	else
	{
		echo mysqli_error(); 
	}

?>