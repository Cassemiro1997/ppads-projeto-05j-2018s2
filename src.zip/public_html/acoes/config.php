<?php	  

        $host = "localhost";
        $user = "id7052837_cassemiro1997";
        $pass = "mackenzie";
        $banco = "id7052837_ajudeummorador";
	  
	  $conexao = mysqli_connect($host, $user, $pass, $banco) or die(mysql_error()); //abrindo conexao
	  
	  mysqli_select_db($conexao, $banco) or die(mysql_error()); //abrindo conexao
?>