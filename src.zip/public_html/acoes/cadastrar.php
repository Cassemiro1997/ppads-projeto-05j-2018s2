<?php 
	header ('Content-type: text/html; charset="utf-8"');
	include("config.php");
	
	$rua = $_POST['rua'];
	$ponto_referencia = $_POST['ponto_referencia'];
	$quantidade = $_POST['quantidade'];
	$doacao = $_POST['doacao'];
	$observacao = $_POST['observacao'];
	
	if(mysqli_query($conexao, "INSERT INTO cadastro_morador (rua, ponto_referencia, quantidade, doacao, observacao)VALUES('$rua', '$ponto_referencia', '$quantidade', '$doacao', '$observacao')"))
	{
		echo "INCLUS�O FEITA COM SUCESSO! <a href='../inserir.php'>VOLTAR</a>";
	}
	else
	{
		echo mysqli_error(); 
	}

?>